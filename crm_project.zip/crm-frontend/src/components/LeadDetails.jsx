import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api';
import { useDispatch } from 'react-redux';
import { patchLead } from '../features/leads/leadsSlice';

export default function LeadDetails() {
  const { id } = useParams();
  const [lead, setLead] = useState(null);
  const [note, setNote] = useState('');
  const [outcome, setOutcome] = useState('approached');
  const dispatch = useDispatch();

  useEffect(() => { api.get(`/leads/${id}`).then(res => setLead(res.data)).catch(console.error); }, [id]);

  const addActivity = async () => {
    const activity = { id: Date.now(), type: 'interaction', date: new Date().toISOString().split('T')[0], notes: note, outcome };
    const updated = { ...lead, activities: [...(lead.activities || []), activity], updatedAt: new Date().toISOString() };

    if (outcome === 'approached') {
      updated.status = 'approached';
      updated.flags = [...(lead.flags||[]), 'contacted'];
    } else if (outcome === 'to_be_contacted_again') {
      updated.status = 'to_be_contacted_again';
    } else if (outcome === 'agreed') {
      updated.status = 'onboarding';
      updated.flags = [...(lead.flags||[]), 'awaiting_account_open'];
    } else if (outcome === 'prospect') {
      updated.status = 'prospect';
    } else if (outcome === 'no_need') {
      updated.status = 'no_need';
      updated.flags = [...(lead.flags||[]), 'no_relationship'];
    }

    try {
      await api.patch(`/leads/${lead.id}`, updated);
      setLead(updated);
      await dispatch(patchLead(lead.id, updated));
      setNote('');
    } catch (err) { console.error(err); }
  };

  if (!lead) return <div>Loading lead...</div>;

  return (
    <div className="card p-3">
      <h4>{lead.customerName}</h4>
      <p><strong>Category:</strong> {lead.category}</p>
      <p><strong>Primary:</strong> {lead.primaryContact?.name} — {lead.primaryContact?.phone} — {lead.primaryContact?.email}</p>

      <h5>Activities</h5>
      <ul>
        {(lead.activities || []).map(a => (<li key={a.id}>{a.date} — {a.type} — {a.notes} — outcome: {a.outcome || a.outcome}</li>))}
      </ul>

      <div className="mt-3">
        <h6>Record new interaction</h6>
        <textarea className="form-control mb-2" value={note} onChange={e => setNote(e.target.value)} placeholder="Notes about call/visit" />
        <select className="form-select mb-2" value={outcome} onChange={e => setOutcome(e.target.value)}>
          <option value="approached">Customer approved meeting / will meet</option>
          <option value="to_be_contacted_again">Ask to call after X days (follow-up)</option>
          <option value="agreed">Agreed to onboarding (waiting to open account)</option>
          <option value="prospect">Prospect (needs management decisions)</option>
          <option value="no_need">No need / rejected</option>
        </select>
        <button className="btn btn-primary" onClick={addActivity}>Save interaction</button>
      </div>
    </div>
  );
}
