import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchLeads, patchLead } from '../features/leads/leadsSlice';
import { Link } from 'react-router-dom';

export default function LeadList() {
  const dispatch = useDispatch();
  const { items, loading } = useSelector(s => s.leads);

  useEffect(() => { dispatch(fetchLeads()); }, [dispatch]);

  const changeStatus = async (lead, status, extra = {}) => {
    const updated = { ...lead, status, updatedAt: new Date().toISOString(), ...extra };
    await dispatch(patchLead(lead.id, updated));
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      <h4>Leads</h4>
      <table className="table table-sm">
        <thead><tr><th>Name</th><th>Category</th><th>Primary Contact</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          {items.map(l => (
            <tr key={l.id}>
              <td><Link to={`/leads/${l.id}`}>{l.customerName}</Link></td>
              <td>{l.category}</td>
              <td>{l.primaryContact?.name} <br/> {l.primaryContact?.phone}</td>
              <td>{l.status} {l.flags?.length ? <span className="badge bg-info ms-2">{l.flags.join(', ')}</span> : null}</td>
              <td>
                <button className="btn btn-sm btn-outline-success me-1" onClick={() => changeStatus(l, 'approached', { flags: [...(l.flags||[]), 'contacted'] })}>Mark Approached</button>
                <button className="btn btn-sm btn-outline-primary me-1" onClick={() => changeStatus(l, 'onboarding', { flags: [...(l.flags||[]), 'awaiting_account_open'] })}>Mark Onboard</button>
                <button className="btn btn-sm btn-outline-warning" onClick={() => changeStatus(l, 'prospect')}>Mark Prospect</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
