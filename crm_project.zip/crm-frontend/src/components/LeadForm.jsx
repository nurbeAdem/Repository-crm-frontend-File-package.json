import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { createLead, patchLead } from '../features/leads/leadsSlice';

export default function LeadForm({ existing, onSaved }) {
  const dispatch = useDispatch();
  const [form, setForm] = useState(existing || {
    customerName: '', category: 'Retail', primaryContact: { name: '', position: '', phone: '', email: '' }, secondaryContact: { name: '', position: '', phone: '', email: '' }, physicalAddress: ''
  });

  const handleChange = (path, value) => {
    const newForm = { ...form };
    const keys = path.split('.');
    let ptr = newForm;
    while (keys.length > 1) {
      const k = keys.shift(); ptr[k] = ptr[k] || {}; ptr = ptr[k];
    }
    ptr[keys[0]] = value;
    setForm(newForm);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      if (existing && existing.id) {
        await dispatch(patchLead(existing.id, { ...form, updatedAt: new Date().toISOString() }));
      } else {
        await dispatch(createLead({ ...form, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), status: 'new', flags: [], activities: [] }));
      }
      onSaved && onSaved();
    } catch (err) {
      alert('Save failed: ' + err.message);
    }
  };

  return (
    <form onSubmit={onSubmit} className="card p-3 mb-3">
      <h5>{existing ? 'Edit Lead' : 'Add Lead'}</h5>
      <div className="mb-2">
        <label className="form-label">Customer Name</label>
        <input className="form-control" value={form.customerName} onChange={e => handleChange('customerName', e.target.value)} required/>
      </div>
      <div className="mb-2">
        <label className="form-label">Category</label>
        <select className="form-select" value={form.category} onChange={e => handleChange('category', e.target.value)}>
          <option>Retail</option><option>Corporate</option><option>Business</option><option>SME</option>
        </select>
      </div>
      <div className="mb-2">
        <label className="form-label">Primary Contact Name</label>
        <input className="form-control" value={form.primaryContact.name} onChange={e => handleChange('primaryContact.name', e.target.value)} />
      </div>
      <div className="row">
        <div className="col">
          <label className="form-label">Primary Phone</label>
          <input className="form-control" value={form.primaryContact.phone} onChange={e => handleChange('primaryContact.phone', e.target.value)} />
        </div>
        <div className="col">
          <label className="form-label">Primary Email</label>
          <input className="form-control" value={form.primaryContact.email} onChange={e => handleChange('primaryContact.email', e.target.value)} />
        </div>
      </div>
      <div className="mb-2 mt-2">
        <label className="form-label">Address</label>
        <input className="form-control" value={form.physicalAddress} onChange={e => handleChange('physicalAddress', e.target.value)} />
      </div>
      <button className="btn btn-primary">{existing ? 'Save Changes' : 'Add Lead'}</button>
    </form>
  );
}
