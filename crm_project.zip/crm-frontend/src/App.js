import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import LeadUpload from './components/LeadUpload';
import LeadForm from './components/LeadForm';
import LeadList from './components/LeadList';
import LeadDetails from './components/LeadDetails';

export default function App() {
  return (
    <div className="container my-4">
      <header className="d-flex justify-content-between align-items-center mb-4">
        <h2>CRM System</h2>
        <nav>
          <Link className="btn btn-outline-secondary me-2" to="/">Leads</Link>
          <Link className="btn btn-outline-primary me-2" to="/add">Add Lead</Link>
          <Link className="btn btn-outline-info" to="/upload">Bulk Upload</Link>
        </nav>
      </header>

      <Routes>
        <Route path="/" element={<LeadList />} />
        <Route path="/add" element={<LeadForm onSaved={() => window.location = '/'} />} />
        <Route path="/upload" element={<LeadUpload />} />
        <Route path="/leads/:id" element={<LeadDetails />} />
      </Routes>
    </div>
  );
}
