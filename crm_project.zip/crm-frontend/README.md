# CRM Frontend

React frontend for the CRM project.

## Setup

1. `cd crm-frontend`
2. `npm install`
3. Copy `.env.example` to `.env` and set `REACT_APP_API_URL` to your backend URL (e.g. http://localhost:4000)
4. `npm start`

## Deploy

Build and deploy to Netlify / Vercel / GitHub Pages. Set environment variable `REACT_APP_API_URL` to point to your deployed backend.
